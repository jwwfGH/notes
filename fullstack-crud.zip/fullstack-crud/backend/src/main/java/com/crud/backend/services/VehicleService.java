package com.crud.backend.services;

import com.crud.backend.dtos.VehicleDto;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VehicleService {
    public List<VehicleDto> allVehicles() {

    }
}
