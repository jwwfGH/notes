package com.crud.backend.dtos;

import lombok.*;
import org.antlr.v4.runtime.misc.NotNull;

@AllArgsConstructor // Constructor for all fields (unlike @RequiredArgsConstructor)
@NoArgsConstructor
@Builder
@Data // Bundles @Getter, @Setter, @To.String
@Getter // Generates getters for each field.
@Setter // Generate setters for each field.
public class VehicleDto {
    private Long id;

    @NotNull
    private String brand;

    @NotNull
    private String model;

    @NotNull
    private String color;

    private int year;
}
