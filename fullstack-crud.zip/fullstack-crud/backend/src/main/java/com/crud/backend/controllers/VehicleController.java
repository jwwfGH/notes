package com.crud.backend.controllers;

import com.crud.backend.dtos.VehicleDto;
import com.crud.backend.services.VehicleService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RequiredArgsConstructor // Constructor for required (final/@NonNull) fields only (unlike @AllArgsConstructor)
@RestController
public class VehicleController {
    private final VehicleService vehicleService;

    @GetMapping("/vehicles")
    public ResponseEntity<List<VehicleDto>> allVehicles() {
        return ResponseEntity.ok(vehicleService.allVehicles());
    }
}
